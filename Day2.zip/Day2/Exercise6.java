package Day2;

import java.util.Scanner;

public class Exercise6 {
	public static void main(String args[]) {
		Scanner sm= new Scanner(System.in);
		String email= sm.nextLine();
		
		if(email.endsWith("@company.com")) {
			System.out.println("Valid Company Email ");
		}
		else {
			System.out.println("Invalid Company Email");
		}
	}
}
