package Day2;
import java.util.*;
import java.math.*;
public class Exercise1 {
	public static void main(String[] args) {
		Scanner sm=new Scanner(System.in);
		int n=sm.nextInt();
		int[] salary = new int[n];
		int av=0 , c=0;
		for(int i=0;i<n;i++) {
			salary[i]=sm.nextInt();
			av=av+salary[i];
		}
		int mx=salary[0] , mn=salary[0];
		int avg = av/n;
		for(int i=0;i<n;i++) {
			mx=Math.max(mx, salary[i]);
			mn=Math.min(mn, salary[i]);
			if(avg<salary[i]) {
				c++;
			}
		}
		System.out.println("Highest Salary: "+mx);
		System.out.println("Lowest Salary: "+mn);
		System.out.println("Average Salary: "+avg);
		System.out.println("Employees Earning Above Average: "+c);
	}
}
