package Day2;

import java.util.Scanner;

public class Exercise2 {
	public static void main(String[] args) {
		Scanner sm = new Scanner(System.in);
		int n=sm.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=sm.nextInt();
		}
		int mx=arr[0];
		int mx2=arr[0];
		for(int i=0;i<n;i++) {
			mx=Math.max(mx,arr[i]);
		}
		for(int i=0;i<n;i++) {
			if(mx!=arr[i]) {
				mx2=Math.max(mx2, arr[i]);
			}
		}
		System.out.println("Second Largest Element: "+mx2);
	}
}
