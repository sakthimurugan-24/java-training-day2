package Day2;

import java.util.Scanner;

public class Exercise8 {
	public static void main(String args[]) {
		Scanner sm = new Scanner(System.in);
		String n=sm.nextLine();
		StringBuffer ab = new StringBuffer(n);
		for(int i=0;i<6;i++) {
			ab.replace(i, i+1, "*");
		}
		
		 System.out.println(ab);
	}
}
