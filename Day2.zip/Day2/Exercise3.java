package Day2;

import java.util.Scanner;

public class Exercise3 {
	public static void main(String[] args) {
		Scanner sm = new Scanner(System.in);
		int n=sm.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=sm.nextInt();
		}
		int j=0 , c=0;
		int[] res=new int[n];
		for(int i=0;i<n;i++) {
			if(arr[i]!=0) {
				res[j]=arr[i];
				j++;
			}
			if(arr[i]==0) {
				c++;
			}
		}
		for(int i=0;i<c;i++) {
			res[j]=0;
			j++;
		}
		for(int i=0;i<n;i++) {
			System.out.print(res[i]+" ");
		}
	}
}
