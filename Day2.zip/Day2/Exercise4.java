package Day2;

import java.util.Scanner;

public class Exercise4 {
	public static void main(String[] args) {
		Scanner sm=new Scanner(System.in);
		int[][] Student=new int[3][4];
		
		for(int i=0;i<3;i++) {
			for(int j=0;j<4;j++) {
				Student[i][j]=sm.nextInt();
			}
		}
		int[] tot=new int[3];
		int[] avg=new int[3];
		int av=0 , top=0;
		for(int i=0;i<3;i++) {
			for(int j=0;j<4;j++) {
				tot[i] = tot[i] +Student[i][j];
			}
			avg[i]=tot[i]/4;
			if(avg[i]>av) {
				av=avg[i];
				top=i;
			}
		}	
		for(int i=0;i<3;i++) {
			System.out.println("Total mark of Student"+(i+1)+": "+tot[i]);
		}
		for(int i=0;i<3;i++) {
			System.out.println("Average mark of Student"+(i+1)+": "+avg[i]);
		}
		System.out.println("Topper of the Student is Student"+(top+1));
	}
}
