package Day2;

public class Exercise5 {
	public static void main(String[] args) {
		int[][] department = new int[3][];
		department[0] = new int[] {101 , 102 , 103};
		department[1] = new int[] {201 , 202};
		department[2] = new int[] {301 , 302 , 303 , 304};
		
		System.out.println("In Department1 have "+department[0].length+ " Employees");
		System.out.println("In Department2 have "+department[1].length+ " Employees");
		System.out.println("In Department3 have "+department[2].length+ " Employees");
		System.out.println();
		System.out.println("In overall Departments have "+(department[0].length+department[1].length+department[2].length)+ " Employees");
	}
}
