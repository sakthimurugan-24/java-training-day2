package Day2;

import java.util.Scanner;

public class Exercise7 {
	public static void main(String[] args) {
		Scanner sm= new Scanner(System.in);
		String word=sm.nextLine();
		String[] words = word.trim().split("\\s+");
		
		System.out.println("The Number of Word is "+words.length);
	}
}
